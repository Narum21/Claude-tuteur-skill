# Révision d'examen (QCM, partiel) — fiche du tuteur

Méthode tirée d'une révision réussie : analyser comment le prof interroge avant de réviser le contenu.

## 1. Inventorier les sources
Slides, scripts ou exercices de chaque séance, classworks, anciens sujets et corrigés, format de l'épreuve (nombre de questions, une ou plusieurs bonnes réponses, points négatifs, durée, documents autorisés).

## 2. Décoder la logique du correcteur
Dans les sujets déjà donnés, cherche les régularités : une question par notion de diapositive ? bonne réponse = celle qui distingue deux notions que l'on confond ? distracteurs récurrents ? Formule la règle et applique-la aux séances sans sujet.

## 3. Pronostiquer
Classe les notions en **Certain / Très probable / Possible**, chacune avec sa séance d'origine et la confusion testée (ex. `[` vs `[[`, `rep(times=)` vs `rep(each=)`, glissement annuel vs taux trimestriel).

## 4. Fiches par séance
Pour chaque séance : l'essentiel en quelques lignes, les exemples du cours, un encadré « Piège » pour chaque confusion identifiée. Rester collé aux exemples et au vocabulaire des slides.

## 5. Liste des pièges
Une liste transversale des pièges que le correcteur a déjà tendus ou pourrait tendre, chacun en une ligne : la confusion + la règle qui la tranche.

## 6. S'entraîner
Banque de questions au format exact de l'épreuve. Marque **officiel** les questions reprises des sujets distribués ; les autres sont construites sur le même moule et doivent être présentées comme telles. Pour chaque réponse : pourquoi la bonne est bonne, pourquoi chaque distracteur est faux. Utilise l'outil de quiz interactif s'il est disponible.

## 7. Suivre les erreurs
Quand l'étudiant se trompe, identifie le distracteur qui l'a piégé et la notion à revoir ; reprogramme ces notions avant l'examen.
