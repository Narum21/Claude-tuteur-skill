# Python — fiche du tuteur

## Rendu attendu
- Script ou notebook qui s'exécute de haut en bas dans un noyau redémarré (Kernel → Restart & Run All) ; imports en tête ; chemins relatifs.
- Cellules/sections commentées qui renvoient aux questions des consignes.

## Symptômes → causes
| Symptôme | Cause probable |
|---|---|
| `ModuleNotFoundError` | package non installé dans l'environnement du notebook (`%pip install`) |
| `KeyError: 'col'` | nom de colonne différent (espaces, majuscules) : `df.columns` |
| Colonne numérique en `object` | virgule décimale ou symboles : `pd.read_csv(..., decimal=",")`, `pd.to_numeric(errors="coerce")` |
| Résultats différents à chaque exécution | cellules exécutées dans le désordre, ou graine aléatoire non fixée |
| `SettingWithCopyWarning` | modification d'une vue : utiliser `.loc` ou `.copy()` |
| Taux décalés | données non triées : `sort_values("date")` avant `pct_change()` |

## Taux de croissance (pandas)
`df["tct"] = df["pib"].pct_change() * 100` ; `df["ga"] = df["pib"].pct_change(4) * 100`.
