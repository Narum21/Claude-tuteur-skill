# Stata — fiche du tuteur

## Rendu attendu
- Un do-file commenté qui part des données brutes : `clear all`, `set more off`, `cd` relatif ou macro de chemin, `log using ... , replace` si un log est demandé.
- `tsset`/`xtset` déclaré avant tout opérateur temporel.

## Symptômes → causes
| Symptôme | Cause probable |
|---|---|
| `variable x not found` | faute de frappe, variable pas encore créée, mauvais fichier chargé |
| `type mismatch` | variable texte (`str`) utilisée comme numérique : `destring x, replace` (ou `dpcomma`) |
| `no observations` | condition `if` trop restrictive, ou valeurs manquantes |
| `time variable not set` | `tsset date` oublié |
| `repeated time values` | doublons de dates, ou panel à déclarer avec `xtset id date` |
| Dates affichées comme nombres | format manquant : `format date %tq` |

## Taux de croissance
`gen tct = (pib/L.pib - 1)*100` et `gen ga = (pib/L4.pib - 1)*100` après `tsset`. Trimestre depuis texte « 2006-Q1 » : `gen date = quarterly(subinstr(periode,"-"," ",.), "YQ")`, `format date %tq`.

## Vérification
Faire exécuter le do-file en entier sur une session vide ; `list` de quelques lignes repères ; `assert` sur les valeurs attendues.
