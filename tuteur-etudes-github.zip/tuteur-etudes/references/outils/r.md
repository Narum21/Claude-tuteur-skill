# R — fiche du tuteur

## Rendu attendu
- Un script (ou R Markdown/Quarto) qui s'exécute de haut en bas dans une session vierge : pas de `setwd()` absolu, chemins relatifs ou projet RStudio, `library()` en tête.
- Commentaires qui renvoient aux questions des consignes (`# Q2 : taux de croissance trimestriel`).
- Données brutes lues, jamais modifiées à la main ; les transformations sont dans le code.

## Symptômes → causes
| Symptôme | Cause probable |
|---|---|
| `could not find function` | package non chargé ou non installé |
| `object 'x' not found` | faute de frappe, objet créé plus bas, variable pas dans le data frame (oubli de `df$`) |
| Nombres lus comme texte (`chr`) | virgule décimale : `read.csv2`/`locale(decimal_mark=",")`, ou symboles (`:`) dans la colonne |
| NA partout après un calcul | `NA` en entrée sans `na.rm = TRUE`, ou conversion ratée |
| Décalage dans un taux de croissance | `lag()` de dplyr masqué par `stats::lag`, données non triées par date, ou oubli de `group_by` |
| Regression avec des coefficients absurdes | variable facteur traitée comme numérique ou l'inverse |

## Taux de croissance (dplyr)
`mutate(tct = (pib / dplyr::lag(pib) - 1) * 100, ga = (pib / dplyr::lag(pib, 4) - 1) * 100)` après `arrange(date)`.

## Vérification
Faire relancer le script complet (Session → Restart R, puis Source) ; comparer 2-3 valeurs repères calculées indépendamment.
