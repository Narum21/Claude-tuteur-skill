# Excel — fiche du tuteur

## Réglages à connaître
- Langue de l'interface : les noms de fonctions changent (SOMME.SI/SUMIF, CNUM/VALUE, GAUCHE/LEFT, DROITE/RIGHT, ARRONDI/ROUND, SI/IF, RECHERCHEV/VLOOKUP, MOYENNE/AVERAGE).
- Séparateur d'arguments : `;` si réglages régionaux français, `,` sinon. Si la formule de l'étudiant fonctionne, ne change pas son séparateur.
- Puissance : `^` (AltGr+9 puis espace sur clavier FR).

## Menus utiles (FR → EN)
| Action | FR | EN |
|---|---|---|
| Coller en transposant | Collage spécial → Transposé, Valeurs | Paste Special → Transpose, Values |
| Filtrer | Données → Filtrer | Data → Filter |
| Graphique combiné | Insertion → Graphiques recommandés → Tous → Graphique combiné | Insert → Recommended Charts → All Charts → Combo |
| Changer le type d'une série | Clic droit → Modifier le type de graphique Série | Right click → Change Series Chart Type |
| Étiquettes d'axe en bas | Mise en forme de l'axe → Étiquettes → Position : Bas | Format Axis → Labels → Label Position: Low |
| Étiquettes d'axe horizontal | Sélectionner des données → Modifier | Select Data → Horizontal (Category) Axis Labels → Edit |
| Zone de texte | Insertion → Zone de texte | Insert → Text Box |

Si le graphique combiné est introuvable : insérer un histogramme groupé, puis changer le type de la seconde série en ligne.

## Symptômes → causes fréquentes
| Symptôme | Cause probable | Correction |
|---|---|---|
| Taux de croissance autour de 100 | `-1` oublié ou mal placé : `=(D6/(D5-1)*100)` | `=(D6/D5-1)*100` |
| Taux affiché 145 % au lieu de 1,45 | ×100 **et** format Pourcentage | garder un seul des deux |
| Sommes qui « perdent » une valeur à chaque ligne | plages sans `$` qui glissent à la recopie | `$B$5:$B$86`, touche F4 |
| Valeurs qui avancent une fois toutes les N lignes | critère pointant sur la mauvaise colonne | vérifier la cellule critère |
| SOMME.SI renvoie 0 | critère numérique vs colonne en texte (ou inverse) | CNUM/VALUE sur la colonne |
| Nombre aligné à gauche, point au lieu de virgule | valeur texte, souvent tapée ou collée | effacer, recopier la formule |
| #DIV/0! | référence vers une cellule vide (mauvaise colonne) | vérifier les lettres de colonne |
| Première donnée traitée comme en-tête, tri qui mélange tout | filtre posé une ligne trop bas | désactiver/replacer le filtre |
| Graphique avec des barres géantes « 2007, 2008… » | années numériques prises comme série | ne sélectionner que les valeurs, puis Modifier les étiquettes |
| Creux à zéro en début de courbe | cellules « - » (texte) tracées comme 0 | commencer la sélection à la première vraie valeur |
| Données Eurostat en une ligne, drapeaux intercalés | format de téléchargement horizontal | copier TIME + série, collage transposé, filtrer les lignes vides et les supprimer |

## Vérification par script (openpyxl)
Charger deux fois : `load_workbook(f)` pour les formules, `load_workbook(f, data_only=True)` pour les valeurs en cache. Vérifier pour chaque colonne calculée que la formule de la ligne r est bien le motif attendu (ex. `f'=(D{r}/D{r-1}-1)*100'`), comparer les données à la feuille source, lister `auto_filter.ref`, largeurs de colonnes, puis ouvrir le .xlsx comme zip pour lire `xl/charts/chart*.xml` (plages `<c:f>`, titres `<a:t>`, types) et `xl/drawings/drawing*.xml` (zones de texte, donc le commentaire).
