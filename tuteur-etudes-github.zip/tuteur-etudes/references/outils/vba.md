# VBA — fiche du tuteur

## Attentes fréquentes des profs
- `Option Explicit` en tête de module, variables déclarées et typées.
- Code indenté, commenté, noms explicites ; une procédure = une tâche.
- Pas de `Select`/`Activate` inutiles : référencer `ws.Range(...)` directement.
- Rendu en .xlsm (un .xlsx supprime les macros) : le rappeler avant le dépôt.

## Symptômes → causes
| Symptôme | Cause probable |
|---|---|
| Erreur 9 « L'indice n'appartient pas à la sélection » | nom de feuille/classeur mal orthographié, ou index hors tableau |
| Erreur 13 « Type incompatible » | texte dans une variable numérique, cellule vide ou erreur (#N/A) lue |
| Erreur 91 « Variable objet non définie » | `Set` oublié, ou `Find` qui ne trouve rien |
| Erreur 1004 | plage invalide, feuille protégée, référence hors feuille |
| Boucle infinie / Excel figé | condition de sortie jamais atteinte, compteur non incrémenté |
| Résultats décalés d'une ligne | boucle démarrant sur l'en-tête, ou dernière ligne mal calculée |
| Macro lente | écriture cellule par cellule : lire/écrire des tableaux (`Variant`), `Application.ScreenUpdating = False` |

## Méthode de débogage à enseigner
F8 pas à pas, point d'arrêt (F9), fenêtre Exécution (`Debug.Print`), fenêtre Variables locales. Demander à l'étudiant le message d'erreur exact **et** la ligne surlignée en jaune.

## Dernière ligne robuste
`derniere = ws.Cells(ws.Rows.Count, "A").End(xlUp).Row`
