# Indicateurs conjoncturels — fiche du tuteur

Toujours appliquer d'abord les formules **du cours de l'étudiant** ; celles-ci sont les standards (manuels, Insee).

## Choix des données (séries de PIB)
- Volumes chaînés (prix de l'année précédente chaînés) : neutralise l'inflation. Prix courants = volume + prix, à éviter pour la croissance.
- CVS-CJO (Eurostat : SCA) : sans correction, le taux trimestriel mesure surtout la saisonnalité (ex. chute artificielle au T1).
- Niveau en millions d'euros plutôt qu'indice : mêmes taux, mais niveaux interprétables.
- Repérer les drapeaux « p » (provisoire), « e » (estimé) : à citer dans les limites.

## Formules (X = PIB, t = trimestre, a = année)
| Indicateur | Formule | Remarques |
|---|---|---|
| Taux de croissance trimestriel | (X_t / X_{t-1} − 1) × 100 | vide pour la 1re observation |
| Glissement annuel | (X_t^a / X_t^{a-1} − 1) × 100 | 4 lignes d'écart en trimestriel ; approché par la somme des 4 TCT |
| PIB annuel | somme des 4 trimestres | exclure l'année incomplète |
| Taux de croissance annuel (moyen) | (X^a / X^{a-1} − 1) × 100 | « moyen » = en moyenne annuelle ; si la consigne dit « sur toute la période », ajouter en bonus le TCAM |
| TCAM sur la période | ((X^fin / X^début)^(1/n) − 1) × 100 | n = nombre d'années d'écart (fin − début), pas le nombre d'années |
| Acquis de croissance (au T2) | ((X_1 + X_2 + X_2 + X_2) / X^{a-1} − 1) × 100 | hypothèse : trimestres restants = dernier connu ; seulement pour l'année en cours |

Contrôle avec l'exemple classique Insee 2008-2009 : acquis au T2 2009 = −2,54 %.

## Lectures économiques
- Récession technique : deux TCT négatifs consécutifs.
- Le TCT réagit vite et fort ; le glissement annuel lisse et suit la tendance.
- L'acquis n'est pas une prévision : croissance finale > acquis si l'activité progresse au S2, < si elle recule.
- Données récentes provisoires et révisables (exemple de cours fréquent : T3 2008 France annoncé +0,1 % puis révisé à −0,2 %).
- Épisodes à repérer en Europe : crise financière 2008-2009, crise des dettes 2011-2013, Covid 2020 (chute puis rebond), choc énergétique et inflation 2022-2023.
