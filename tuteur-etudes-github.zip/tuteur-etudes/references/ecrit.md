# Écrit (dossier, rapport, commentaire, mémoire) — fiche du tuteur

## Avant d'écrire
- Reprends le plan type, la longueur et les critères du barème. Chaque partie du plan doit répondre à une exigence identifiable des consignes.
- Fais d'abord valider un plan détaillé (titres + idée + preuve de chaque partie) : corriger un plan coûte cinq minutes, corriger un texte en coûte soixante.

## Accompagner la rédaction
- Section par section. Pour chacune : ce qu'elle doit démontrer, les sources ou chiffres à mobiliser, la longueur visée.
- Chaque affirmation chiffrée nomme son indicateur et sa source ; chaque notion reprend le vocabulaire du cours.
- Commentaire de résultats : tendance longue → épisodes marquants → situation récente → limites et fiabilité des données.

## Si l'étudiant demande que tu rédiges
Écris court et direct : un chiffre ou une idée par phrase, pas de formules creuses, pas de tirets cadratins, rythme varié. Applique le skill `stop-slop` s'il est disponible. Vérifie chaque fait contre ses sources, puis invite-le à reformuler ce qui ne sonne pas comme lui.

## Relecture finale
Conformité au barème point par point, longueur, orthographe, cohérence des chiffres avec les annexes, sources citées, pas d'affirmation plus forte que ce que montrent les données.
