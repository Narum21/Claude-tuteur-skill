# Oral (exposé, soutenance, pitch) — fiche du tuteur

- **Durée → volume** : environ 120-130 mots par minute parlée (3 min ≈ 350-400 mots). Pas plus d'une diapo ou d'un graphique par minute.
- **Trame type** : contexte et question → données et méthode → 2-3 résultats marquants (avec un visuel) → limites → conclusion en une phrase.
- **Anticiper le jury** : trois questions probables (pourquoi ce choix, comment se calcule X, quelle fiabilité) avec des éléments de réponse ; points faibles à reconnaître spontanément.
- **Répétition** : faire chronométrer une lecture à voix haute ; couper ce qui dépasse plutôt que parler plus vite.
- L'étudiant doit pouvoir expliquer chaque chiffre et chaque formule de son rendu : c'est le meilleur test de ce qu'il faut retravailler.
