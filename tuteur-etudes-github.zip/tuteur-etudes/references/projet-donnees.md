# Projet de données — fiche du tuteur

## Récupérer les bonnes données
- Donne les paramètres exacts (jeu de données, codes, unité, correction saisonnière, période, champ) et la raison de chaque choix, rattachée au cours.
- Période : au-delà du minimum demandé, commençant sur une unité complète (T1, janvier), couvrant des épisodes utiles au commentaire.
- **Quand le fichier arrive, vérifie-le par script** : métadonnées, nombre d'observations, valeurs manquantes, drapeaux (provisoire, estimé), feuilles/colonnes en trop. Explique la conséquence de chaque problème.
- Données brutes intactes : copie de l'original à part ; dans le fichier de travail, ne supprime ni ne renomme les feuilles sources.

## Structurer
- Tableur : feuille de calcul séparée, une ligne par observation, une colonne par variable, en-têtes avec unités, identifiants dérivés par formule. Code : un script unique, commenté, qui part des données brutes et s'exécute de bout en bout sur une session vierge.
- Titre, source complète (organisme, code du jeu, unité, date d'extraction), légende des drapeaux.
- Valeurs repères de structure : première/dernière ligne, nombre de lignes.

## Calculer
- Toute valeur calculée l'est par une formule ou du code visible, jamais tapée à la main.
- Formatage d'affichage plutôt qu'arrondi dans les calculs intermédiaires.
- Valeurs repères : calcule-les toi-même par script sur les données de l'étudiant, 2 à 4 points dont un épisode marquant. Sans données, déduis-les des chiffres qu'il te donne, ou dis ce qu'on doit observer (ex. « autour de 0 »).

## Graphiques
Un graphique principal qui compare les indicateurs, un secondaire facultatif pour l'oral. Donne la sélection exacte, le type, les pièges (texte tracé comme zéro, années prises pour une série, étiquettes au milieu des valeurs négatives), un titre complet avec unité et période, la source dessous.

## Contrôle final d'un fichier
Données identiques à la source ; chaque colonne calculée = même formule sur toute la plage, sans valeur en dur ; recalcul indépendant des résultats clés ; plages et titres des graphiques ; filtre actif, colonnes trop étroites, titre, source, acronymes ; texte du commentaire (y compris dans les zones de texte) : fautes, chiffres, affirmations inexactes par rapport aux données.
